import React from 'react';
import {Routes, Route, Link } from 'react-router-dom';
import AboutUs from './components/aboutus';
import Home from './components/home';
import Careers from './components/careers';
import ContactUs from './components/contactus';
import Investors from './components/investors';
import Sustainability from './components/sustainability';
import Login from './components/login';
import Welcome from './components/welcome';
import Form from './signup'
import logo_1 from './logo_1.png';
import './App.css';

function App() {
  return (
    <>
      <div className="App">
      <div className='logo_1'>
        <img src={logo_1}></img>
      </div>
      <div className='nav'>
        <nav>
          <ul>
          <li>
              <Link to="/home">Home</Link>
            </li>
            <li>
              <Link to="/about">About Us</Link>
            </li>
            <li>
              <Link to="/sustainability">Sustainability</Link>
            </li>
            <li>
              <Link to="/careers">Careers</Link>
            </li>
            <li>
              <Link to="/investors">Investors</Link>
            </li>
            <li>
              <Link to="/contact">Contact Us</Link>
            </li>
            <li>
              <Link to="/login" className='Login'>Login</Link>
            </li>
          </ul>
          <div>
              <button  className='sign_up'><Link to='/signup'>Sign up</Link></button>
          </div>
        </nav>
      </div>

      
      <Routes>
        <Route path='/signup' element={<Form />} />
        </Routes>

          <Routes>
            <Route path="/Home" element={<Home />} />         
            <Route path="/about" element={<AboutUs />} />
            <Route path="/sustainability" element={<Sustainability/>} />
            <Route path="/careers" element={<Careers/>} />
            <Route path="/investors" element={<Investors/>} />
            <Route path="/contact" element={<ContactUs/>} />
            <Route path="/login" element={<Login/>} />
            <Route path="/welcome" element={<Welcome />}/>
          </Routes>
      </div>

    </>
  );
}

export default App;