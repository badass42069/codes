import React from 'react';

function ContactUs() {
  return (
    <div>
      <h2>Operating Offices</h2>
      <p>
        Village Tunda & Siracha, Taluka Mundra, Mundra, Kutch 370 435, Gujarat, India
        Tel: +91 2838 26 6128
        Fax: +91 2838 26 6128
      </p>
    </div>
  );
}

export default ContactUs;