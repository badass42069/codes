import React from 'react';

function Sustainability() {
  return (
    <div>
      <h2>Sustainability</h2>
      <p>Lighting up aspirations of young India, sustainably</p>
      <p>In the evolving landscape of India’s energy industry, Adani Power Limited (APL) has not only stayed resilient but has also grown stronger. From setting new benchmarks through cutting edge technology to empowering communities with well-defined human development goals, we believe that growth is best driven by sustainable footprints. We diligently follow responsible Environmental, Social and Governance (ESG) principles and have implemented effective corporate governance, robust risk management and stringent safety measures across our operations. Adani Power Limited has emerged as the leader in India’s electric utility sector on ESG benchmarking for the year 2019 conducted by S&P Dow Jones Indices and SAM. </p>
    </div>
  );
}

export default Sustainability;