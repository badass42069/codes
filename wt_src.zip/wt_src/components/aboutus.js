import React from 'react';

function AboutUs() {
  return (
    <div>
      <h2>About Us</h2>
      <p>Adani Power Limited (APL), a part of the diversified Adani Group, is the largest private thermal power producer in India. We have a power generation capacity of 12,450 MW comprising thermal power plants in Gujarat, Maharashtra, Karnataka, Rajasthan, and Chhattisgarh and a 40 MW solar power project in Gujarat.

We were the world’s first company to set up a coal-based Supercritical thermal power project registered under the Clean Development Mechanism (CDM) of the Kyoto protocol. Being a new entrant to power generation in 2006, we leveraged the project management skills of the Adani Group to set up our first power plant at Mundra successfully and efficiently.

The power sector in India has undergone a challenging period in the past few years, which put to test the resilience of our business model. By navigating the challenges through prudence, persistence and discipline, we have implemented the best available technologies and practices that can serve as benchmarks for the power industry.

As we augment our generation capacity, both organically and inorganically, we also strive to make our footprints sustainable. Receiving a percentile score of 65 for AdaniPower in Corporate Sustainability Assessment by DJSI-S&P Global and a leading position in India and number 30th in world in ESG benchmarking for 2019, makes us more committed for Growth with Goodness. This ESG score is testimony of the company’s corporate sustainability practices.</p>
    </div>
  );
}

export default AboutUs;