import React from 'react';
import { Link } from 'react-router-dom';

function Welcome() {
  return (
    <div>
      <h1>You have been logged in</h1>
      <p>Click here to logout.</p>
      <Link to="/login">Logout</Link>
    </div>
  );
}

export default Welcome;
