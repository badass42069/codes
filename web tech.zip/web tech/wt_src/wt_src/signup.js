import React from "react";
import { useState } from "react";

function Form() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [sub, setSub] = useState(false);

    const handleSubmit = (e) => {
        e.preventDefault();
        setSub(true);
    }

    return (
        <div>
            <form onSubmit={handleSubmit} className="signupform">
                <label>Name</label>
                <input type="text" value={name} onChange={(e) => { setName(e.target.value) }} />
                <label>Business Email</label>
                <input type="email" value={email} onChange={(e) => { setEmail(e.target.value) }} />
                <label>Phone number</label>
                <input value={phone} onChange={(e) => { setPhone(e.target.value) }} />
                <button>Submit</button>
            </form>
            {sub && (
                <div>
                    <h2>Details</h2>
                    <p>Name: {name}</p>
                    <p>Email: {email}</p>
                    <p>Team Size: {phone}</p>
                </div>
            )}
        </div>
    );
}

export default Form;
