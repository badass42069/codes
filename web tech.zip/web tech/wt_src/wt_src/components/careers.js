import React from 'react';

function Careers() {
  return (
    <div>
      <h2>Careers</h2>
      <p>Explore positions</p>
      <p>Our people are the key drivers of the Adani Group’s core philosophy of Growth with Goodness. Join the family, to explore unprecedented opportunities and discover a purpose in life.</p>
    </div>
  );
}

export default Careers;