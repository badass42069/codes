import React, { useState } from 'react';

// Sample local list of users and passwords
const userList = [
  { username: 'user1', password: 'Password1' },
  { username: 'user2', password: 'Password2' },
  // Add more users as needed
];

function Login() {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const { username, password } = formData;

    // Validate the password format
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(password)) {
      setError('Password must have 1 lowercase, 1 uppercase, and 1 number.');
      return;
    }

    // Check if the provided username and password match any entries in the local list
    const user = userList.find((user) => user.username === username && user.password === password);
    if (user) {
      // Successful login; navigate to the welcome page
      // Use the Link component to navigate
      // Replace '/welcome' with the actual URL of your welcome page
      window.location.href = '/welcome';
    } else {
      setError('Invalid username or password.');
    }
  };

  return (
    <div>
      <h1>Login Page</h1>
      <form onSubmit={handleLogin}>
        <div>
          <label htmlFor="username">Username:</label>
          <input type="text" id="username" name="username" value={formData.username} onChange={handleInputChange} required />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input type="password" id="password" name="password" value={formData.password} onChange={handleInputChange} required />
        </div>
        {error && <p className="error">{error}</p>}
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;
