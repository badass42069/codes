import React from 'react';

function Investors() {
  return (
    <div>
      <h2>Investor Contact</h2>
      <p>Institutional Investors and Research Analysts contact:</p>
      
      <p>Nishit Dave
      Head-Investor Relations, Adani Power Ltd
      Nishit.Dave@adani.com

      D. Balasubramanyam
      Group Head- Investor Relations, Adani Group
      Email: D.Balasubramanyam@adani.com</p>
    </div>
  );
}

export default Investors;