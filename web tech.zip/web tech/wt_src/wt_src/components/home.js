import React from 'react';

function Home() {
  return (
    <div>      
       <h2>Home</h2>
      <p>Welcome to the site.</p>
    </div>
  );
}

export default Home;