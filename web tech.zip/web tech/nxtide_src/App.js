import React from 'react';
import './App.css';
import logo_1 from './logo_1.png';
import NAV from './Nav_Bar';
import FC from './First_Component';
import Dev from './dev_div';
import Form from './customer_form';

function App() {
  return(
    <>
    <NAV />
    <FC></FC>
    <Dev></Dev>               
    </>
  );
}

export default App;