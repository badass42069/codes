import React from 'react';
import './App.css';
import logo_1 from './logo_1.png';

function NAV() {
  return(
    <div className='navbar'>
      <div className='logo_1'>
        <img src={logo_1}></img>
      </div>
    <nav>
      <ul>
        Features
      </ul>
      <ul>
        Pricing
      </ul>
      <ul>
        Use Cases
      </ul>
      <ul>
        Request a Demo
      </ul>    
      <div class="dropdown">
        <button class="dropbtn">More
            <i class="fa fa-caret-down"></i>
        </button>
            <div class="dropdown-content">
              <a>Contact us</a>
              <a>Support</a>
              <a>Jobs</a>
              <a>Partners</a>
            </div>
      </div>
    </nav>
    <div className='sign_up'>
      <button className='l_b'>Log in</button>
      <button className='s_b'>Sign Up</button>
    </div>
    </div>
  );
}


export default NAV;


<div class="navbar">
  <a href="#home">Home</a>
  <a href="#news">News</a>
  <div class="dropdown">
    <button class="dropbtn">Dropdown
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div>
</div>