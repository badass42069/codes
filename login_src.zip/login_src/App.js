import React, { useState } from 'react';
import './App.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');

  const users = [
    { username: 'rishi', name: 'Rishi', password: 'RSishi123' },
    { username: 'chef', name: 'Heisenberg', password: 'walterwhite' },
  ];

  const handleLogin = (enteredUsername, enteredPassword) => {
      const matchedUser = users.find(
        (user) =>
          user.username === enteredUsername && user.password === enteredPassword
      );

      const lowercaseRegex = /[a-z]/;
      const uppercaseRegex = /[A-Z]/;
      const numberRegex = /[0-9]/;
  
      const isPasswordValid =
        lowercaseRegex.test(enteredPassword) &&
        uppercaseRegex.test(enteredPassword) &&
        numberRegex.test(enteredPassword);
  
      if (matchedUser && isPasswordValid) {
        setUsername(enteredUsername);
        setName(matchedUser.name);
        setIsLoggedIn(true);
      } else {
        if (!isPasswordValid) {
          alert(
            'Password must contain at least one lowercase letter, one uppercase letter, and one number.'
          );
        } else {
          alert('Invalid username or password. Please try again.');
        }
      }
    };

  const handleLogout = () => {
    setUsername('');
    setName('');
    setIsLoggedIn(false);
  };

  return (
    <div className="App">
      {isLoggedIn ? (
        <div>
          <h2>Welcome, {name} ({username})!</h2>
          <button onClick={handleLogout}>Logout</button>
        </div>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleLogin(
              e.target.username.value,
              e.target.password.value
            );
          }}
        >
          <input
            type="text"
            name="name"
            placeholder="Name"
            required
          />
          <input
            type="text"
            name="username"
            placeholder="Username"
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            required
          />
          <button type="submit">Login</button>
        </form>
      )}
    </div>
  );
}

export default App;
