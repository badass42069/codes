import React from 'react';
import { Routes, Link, Route } from 'react-router-dom';
import Form from './customer_form';
import logo from './people.png'

function FC() {

    return(
        <>
        <div className='container'>
            
            <div className='left_div'>
                <h1 style={{fontSize: '50px', marginTop: '69px'}}>Get your team working in sync</h1>
                <p style={{fontSize: '18px', marginTop: '22px'}}>Build powerful low-code business solutions to customize work and communication</p>
                <button className='scb' ><Link to='/csf'>Schedule a Call</Link><span style={{position: 'absolute'}}>&rarr;</span></button>
            </div>
            <div className='right_div'>
            
            </div>  
            </div>
    

        <Routes>
        <Route path='/csf' element={<Form />} />
        </Routes>


        </>
    );
}

export default FC;